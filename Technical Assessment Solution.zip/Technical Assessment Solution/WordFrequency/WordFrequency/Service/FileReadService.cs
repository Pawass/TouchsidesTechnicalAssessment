﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Configuration;
using System.IO;
using System.Text.RegularExpressions;

namespace WordFrequency
{
    public static class FileReadService
    {
        private static Regex _regexClean = new Regex("[^a-zA-Z0-9]");

        public static void Readfile(string myfile)
        {
            try
            {
                string alltext = string.Empty;

                //reading all text in the file
                alltext = File.ReadAllText(myfile);

                //replace non number and non letters with spaces using regex
                alltext = _regexClean.Replace(alltext, " ");
                string[] allwords = alltext.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                //get all distinct words within the file
                var distinctwords = (from mydistinctwords in allwords
                                     select mydistinctwords.ToLowerInvariant()).Distinct().ToList();
                //process the frequencies
                GetEachWordFrequenty(allwords);
                //get scrabble highest score
                GetScrabbleScore(distinctwords);
            }
            catch(Exception ex)
            {
                Console.WriteLine("Failed to read the file \n" + ex.ToString());
            }


        }

        private static void GetEachWordFrequenty(string[] allwords)
        {
            //initialising dictionaries to store words and frequencies
            Dictionary<string, int> allmywordcount = new Dictionary<string, int>();
            Dictionary<string, int> my7charwords = new Dictionary<string, int>();

            // Group each word with number of occurances
            var countwords = allwords.GroupBy(w => w.ToLowerInvariant())
           .Select(g => new { Word = g.Key, Count = g.Count() })
           .ToList();

            // add dictionary info
           foreach( var appear in countwords)
            {
                allmywordcount.Add(appear.Word, appear.Count);
                if(appear.Word.Length == 7)
                {
                    my7charwords.Add(appear.Word, appear.Count);

                }

            }

           //get actual word frequencies
            var mostfrequentvalue = allmywordcount.Values.Max();
            var ostfrequentword= allmywordcount.Aggregate((x, y) => x.Value > y.Value ? x : y).Key;
            //display result
            Console.WriteLine();
            Console.WriteLine("Most frequent word: " + ostfrequentword + " occured " + mostfrequentvalue + " times");
          

            var mostfrequent7wordvalue = my7charwords.Values.Max();
            var mostfrequent7word = my7charwords.Aggregate((x, y) => x.Value > y.Value ? x : y).Key;
            Console.WriteLine();
            Console.WriteLine("Most frequent 7-character word: " + mostfrequent7word + " occured " + mostfrequent7wordvalue + " times");
            Console.WriteLine();
           
         }

        private static void GetScrabbleScore(List<string> diswords)
        {
            
            Dictionary<string, int> scrabble = new Dictionary<string, int>();
            //looping through each word and getting its sum
            foreach(var word in diswords)
            {
                char? eachchar = null;

                int sum = 0;
                for(int i = 0; i < word.Length; i++)
                {
                    eachchar = char.ToUpper(word[i]);
                    
                    switch (eachchar)
                    {
                        case 'A':
                            sum += 1;
                            continue;
                        case 'B':
                            sum += 3;
                            continue;
                        case 'C':
                            sum += 3;
                            continue;
                        case 'D':
                            sum += 2;
                            continue;
                        case 'E':
                            sum += 1;
                            continue;
                        case 'F':
                            sum += 4;
                            continue;
                        case 'G':
                            sum += 2;
                            continue;
                        case 'H':
                            sum += 4;
                            continue;
                        case 'I':
                            sum += 1;
                            continue;
                        case 'J':
                            sum += 8;
                            continue;
                        case 'K':
                            sum += 5;
                            continue;
                        case 'L':
                            sum += 1;
                            continue;
                        case 'M':
                            sum += 3;
                            continue;
                        case 'N':
                            sum += 1;
                            continue;
                        case 'O':
                            sum += 1;
                            continue;
                        case 'P':
                            sum += 3;
                            continue;
                        case 'Q':
                            sum += 10;
                            continue;
                        case 'R':
                            sum += 1;
                            continue;
                        case 'S':
                            sum += 1;
                            continue;
                        case 'T':
                            sum += 1;
                            continue;
                        case 'U':
                            sum += 1;
                            continue;
                        case 'V':
                            sum += 4;
                            continue;
                        case 'W':
                            sum += 4;
                            continue;
                        case 'X':
                            sum += 8;
                            continue;
                        case 'Y':
                            sum += 4;
                            continue;
                        case 'Z':
                            sum += 10;
                            continue;


                    }

                }
                scrabble.Add(word, sum);
            }
            //get highest score from scrabble dictionary
            var higherstscoringvalue = scrabble.Values.Max();
            var highestscoringword = scrabble.Aggregate((x, y) => x.Value > y.Value ? x : y).Key;
           //display results
            Console.WriteLine("Highest scoring word(s) (according to Scrabble): " + highestscoringword + " with a score of " + higherstscoringvalue );
            Console.WriteLine();
            Console.WriteLine("Processing Done");
            Console.ReadLine();
         

        }

        

    }
}
