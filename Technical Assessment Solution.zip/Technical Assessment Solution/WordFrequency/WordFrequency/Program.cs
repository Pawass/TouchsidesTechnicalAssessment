﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Configuration;
using System.IO;

namespace WordFrequency
{
    class Program
    {
        static readonly  string sProcessedFolder = ConfigurationManager.AppSettings["ProcessedFolder"];
        static readonly string sFailedFolder = ConfigurationManager.AppSettings["FailedFolder"];
        static readonly string sReceivedFolder = @"c:\Received";
        static void Main(string[] args)
        {
            
            int result = 0;
            do
            {
               result = Getuseroption();
                if (result == 1)
                {
                    string UrlLocation = string.Empty;

                    Console.WriteLine("Type URL location and press enter");
                    UrlLocation = Console.ReadLine();
                    Console.WriteLine();
                    Console.WriteLine(" URL  is " + UrlLocation);
                    Console.WriteLine();
                    Console.WriteLine("Processing in progress...");
                    Downloadfile(UrlLocation);
                    Console.ReadLine();
                    Console.WriteLine();
                }
                if (result == 2)
                {
                    
                        Console.WriteLine("Please copy file to this source folder " + sReceivedFolder + " and then press enter");
                        
                        Console.ReadLine();
                        Console.WriteLine();
                        Console.WriteLine("Processing in progress...");
                        ReadFiles();
                }
            } while (result != 3);

            if (result == 3)
            {

                Environment.Exit(0);
            }
        }

        private static int Getuseroption()
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("Where is the file,select option below?");
            Console.WriteLine();
            Console.WriteLine("1. url location");
            Console.WriteLine("2. want to copy it to local source folder");
            Console.WriteLine("3. exit");

            
            if (Int32.TryParse(Console.ReadLine(), out int option))
                return option;

          return option;

        }
        private static void Downloadfile(string urlfileLocation)
        {
            try
            {

                string filename = string.Empty;
                
                string path = string.Empty;
                

                WebClient webClient = new WebClient();
                
                var ur = new Uri(urlfileLocation);

                if (ur.IsAbsoluteUri)
                {
                    filename = Path.GetFileName(ur.LocalPath);
                    if (string.IsNullOrEmpty(filename))
                    {
                        Console.WriteLine("URL does not have a file name");
                        Console.ReadLine();

                    }
                    else
                    {

                        if (!Directory.Exists(sReceivedFolder))
                        {
                            Directory.CreateDirectory(sReceivedFolder);
                        }
                        if (!File.Exists("C:\\Received" + "\\" + filename))
                        {
                            //downloading file to the local folder 
                            webClient.DownloadFile(urlfileLocation, @"C:\Received" + "\\" + filename);
                            //processing file
                            ReadFiles();

                        }
                        else
                        {
                            Console.WriteLine("File name already exist, press enter to get results");
                            
                            Console.ReadLine();
                            Console.WriteLine();
                            ReadFiles();
                        }
                    }
                }
              

               }
            catch (Exception ex)
            {
                Console.WriteLine("Download was not successful! \n" + ex.ToString());
                Console.WriteLine();
                Console.WriteLine("Processing Done");
                Console.ReadLine();

            }
        }

        private static void ReadFiles()
        {
            string[] files = Directory.GetFiles(sReceivedFolder);
            if (files.Length > 0)
            {
                foreach (var file in files)
                {
                    string Extention = Path.GetExtension(file);
                    if (Extention.Contains(".txt"))
                    {
                        FileReadService.Readfile(file);
                        MoveFilesToProcessedFolder(Path.GetFileName(file));


                    }
                    else
                    {
                        Console.WriteLine("File extension not suitable for processing,only text files for now");
                        Console.ReadLine();
                        MoveFilesToFailedFolder(Path.GetFileName(file));
                    }
                }
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Source Folder is empty!");
                Console.WriteLine();
                Console.WriteLine("Processing Done");
                Console.ReadLine();
                
            }

        }
        private static void MoveFilesToProcessedFolder(string filename)
        {
            try
            {
                if (!Directory.Exists(sProcessedFolder))
                {
                    Directory.CreateDirectory(sProcessedFolder);
                }
                if (File.Exists(sProcessedFolder + "\\" + filename))
                {
                    File.Delete(sProcessedFolder + "\\" + filename);
                }

               
                    File.Move("C:\\Received" + "\\" + filename, sProcessedFolder + "\\" + filename);
                
            }
            catch(Exception ex)
            {
                Console.WriteLine("Could not move file to procesed folder \n " + ex.ToString());
            }

        }
        private static void MoveFilesToFailedFolder(string filename)
        {
            try
            {
                if (!Directory.Exists(sFailedFolder))
                {
                    Directory.CreateDirectory(sFailedFolder);
                }

                if (File.Exists(sFailedFolder + "\\" + filename))
                {
                    File.Delete(sFailedFolder + "\\" + filename);
                }

               
                    File.Move(sReceivedFolder + "\\" + filename, sFailedFolder + "\\" + filename);
            }
            catch(Exception ex)
            {
                Console.WriteLine("Could not move file to failed folder \n" + ex.ToString());
            }

        }
    }
}
